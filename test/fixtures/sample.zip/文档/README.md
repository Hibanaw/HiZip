# HiZip

Flutter 界面 + 原生 libarchive 引擎。

- 目录浏览
- 文本与图片预览
- 安全解压
- ZIP 写回
